﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATMMachine
{
    public class ATMDetailsBE
    {
        public ATMDetailsBE()
        {
            Random random = new Random();
            ATMBalance = random.Next(5000, 7000);
        }
        private static double ATMBalance { get; set; }

        public double getATMBalance()
        {
            return ATMBalance;
        }

        public void setATMBalance(double DebitedAmount)
        {
            ATMBalance = ATMBalance - DebitedAmount;
        }
    }
}
