﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATMMachine
{
    public class ATMTransactionBL
    {
        public static string ProcessTransation(AccountDetailsBE accountDetailsBE,TransactionDetailsBE transactionDetailsBE,ATMDetailsBE aTMDetailsBE,out AccountDetailsBE accountDetailsBE1)
        {
            try
            {
                double ATMCash =  aTMDetailsBE.getATMBalance();//get ATM balance
                if(ATMCash > transactionDetailsBE.amountToDebit ) // Check if ATM is having cash available
                {
                    if(transactionDetailsBE.amountToDebit < accountDetailsBE.Balance )//check if account is having enough balance
                    {
                        string output = GetAmountDetails(transactionDetailsBE.amountToDebit);//get Currency division
                        accountDetailsBE.Balance = accountDetailsBE.Balance - transactionDetailsBE.amountToDebit; // Deduct balance from account
                        aTMDetailsBE.setATMBalance(transactionDetailsBE.amountToDebit); // Deduct ATM balance 
                        accountDetailsBE1 = accountDetailsBE;
                        return output + $"\nYour account balance is :{accountDetailsBE.Balance}";
                    }
                    else
                    {
                        accountDetailsBE1 = accountDetailsBE;
                        return $"insufficient amout in your account {accountDetailsBE.Balance}";
                    }
                }
                else
                {
                    accountDetailsBE1 = accountDetailsBE;
                    return "insufficient amout";
                }
            }
            catch(Exception)
            {
                throw;
            }
        }
        private static string GetAmountDetails (double amount)
        {
            try
            {
                IDictionary<int, int> CurrencyDetails = new Dictionary<int, int>();
                IDictionary<int, int> CurrencyDetails1 = new Dictionary<int, int>();
                CurrencyDetails.Add(2000,0);
                CurrencyDetails.Add(500,0);
                CurrencyDetails.Add(200,0);
                CurrencyDetails.Add(100,0);
                double tempAmount = 0;
                string atmCurrencyDetails = string.Empty; 
                foreach(var currency in CurrencyDetails)
                {
                    tempAmount =  amount % currency.Key;
                    if(tempAmount!=amount)
                    {
                        amount = amount - tempAmount;
                        int count = Convert.ToInt32(amount / currency.Key);
                        amount = tempAmount;
                        CurrencyDetails1.Add(currency.Key,count);
                    }
                }

                foreach (var currency in CurrencyDetails1)
                {
                    atmCurrencyDetails = atmCurrencyDetails + $"{ currency.Key}: {currency.Value}\n";
                }
                return atmCurrencyDetails;
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
