﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATMMachine
{
    public class AccountDetailsBE
    {
        public AccountDetailsBE (string AccountHolder, string AccountNumber, string Accounttype, string AccountCategory)
        {
            this.AccountHolder = AccountHolder;
            this.AccountNumber = AccountNumber;
            this.Accounttype = Accounttype;
            this.AccountCategory = AccountCategory;
            Random random = new Random();
            Balance = random.Next(1000, 3000);

        }
        public string AccountHolder { get; set; }
        public string AccountNumber { get; set; }
        public string Accounttype { get; set; }
        public string AccountCategory { get; set; }
        public double Balance { get; set; }
    }

    public class AccountCategoty
    {
        public const string Personal = "Personal";
        public const string Business = "Business";
    }
    public class AccountType
    {
        public const string Saving =  "Saving";
        public const string Checked = "Checked";
    }
}
