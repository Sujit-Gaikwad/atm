﻿using System;
using System.Collections.Generic;

namespace ATMMachine
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Welcome to ATM!");
                IDictionary<string, AccountDetailsBE> Accounts = new Dictionary<string, AccountDetailsBE>();
                Accounts.Add("123", new AccountDetailsBE("ABC", "123", AccountType.Saving, AccountCategoty.Personal));
                Accounts.Add("124", new AccountDetailsBE("ABC", "124", AccountType.Checked, AccountCategoty.Business));
                int wrongInputAttempt = 0;
                int sucessInputAttempt = 0;
                string userInput = string.Empty;
                ATMDetailsBE aTMDetailsBE = new ATMDetailsBE();
                do
                {
                    AccountDetailsBE accountDetailsBE = null;
                    TransactionDetailsBE transactionDetailsBE = new TransactionDetailsBE();
                    Console.WriteLine("Please enter your account number");
                    transactionDetailsBE.accNumber = Console.ReadLine();
                    bool isValidAccount = Accounts.TryGetValue(transactionDetailsBE.accNumber, out accountDetailsBE); //Check if account number is valid or not
                    if (isValidAccount)
                    {
                        Console.WriteLine("Please type your account Type: \n\t1. Saving \n\t2. Checked");
                        transactionDetailsBE.accType = Console.ReadLine();
                        if (transactionDetailsBE.accType.Equals(accountDetailsBE.Accounttype, StringComparison.InvariantCultureIgnoreCase))//check account type
                        {
                            Console.WriteLine("Please type amout to credit (amount should be in multiple of 100):");
                            string amount = Console.ReadLine();
                            if (Double.TryParse(amount, out double amountToDebit))// check if amount is valid or not
                            {
                                if((amountToDebit % 100)==0)
                                {
                                    transactionDetailsBE.amountToDebit = amountToDebit;
                                    Console.WriteLine("Please wait while we process the transaction..");
                                    string transaction = ATMTransactionBL.ProcessTransation(accountDetailsBE, transactionDetailsBE, aTMDetailsBE, out AccountDetailsBE accountDetailsBE1);//process ATM translation
                                    Console.WriteLine("{0}", transaction);
                                    accountDetailsBE = accountDetailsBE1;
                                    sucessInputAttempt++;
                                }
                                else
                                {
                                    Console.WriteLine("Please the amount in multiplication of 100");
                                    wrongInputAttempt++;
                                }
                            }
                            else
                            {
                                Console.WriteLine("Please enter valid amount");
                                wrongInputAttempt++;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Please enter valid account type");
                            wrongInputAttempt++;
                        }

                    }
                    else
                    {
                        Console.WriteLine("Please enter valid account number");
                        wrongInputAttempt++;
                    }
                    Console.WriteLine("Please type you want to continue?");
                    Console.WriteLine("Please type \n\t1.Yes to continue \n\t2. No to complete the transaction");
                    userInput = Console.ReadLine();
                } while (wrongInputAttempt < 2 || sucessInputAttempt < 4 || !(userInput.Equals("yes", StringComparison.InvariantCultureIgnoreCase)));

                Console.ReadKey();
            }
            catch(Exception ex)
            {
                Console.WriteLine("{0}", ex.Message);
            }

        }
    }
}
