﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATMMachine
{
    public class TransactionDetailsBE
    {
        public string accNumber { get; set; }
        public double amountToDebit { get; set; }
        public string accType { get; set; }
    }
}
